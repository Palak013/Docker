#!/bin/bash
exec /usr/local/rvm/bin/rvm-exec "$@"
